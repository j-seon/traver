package vo;

public class MemberInfo {
	private String mi_id, mi_nickname, mi_pw, mi_mbti, mi_name, mi_mail, mi_birth, mi_join, mi_last, mi_status;

	public String getMi_id() {
		return mi_id;
	}

	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}

	public String getMi_nickname() {
		return mi_nickname;
	}

	public void setMi_nickname(String mi_nickname) {
		this.mi_nickname = mi_nickname;
	}

	public String getMi_pw() {
		return mi_pw;
	}

	public void setMi_pw(String mi_pw) {
		this.mi_pw = mi_pw;
	}

	public String getMi_mbti() {
		return mi_mbti;
	}

	public void setMi_mbti(String mi_mbti) {
		this.mi_mbti = mi_mbti;
	}

	public String getMi_name() {
		return mi_name;
	}

	public void setMi_name(String mi_name) {
		this.mi_name = mi_name;
	}

	public String getMi_mail() {
		return mi_mail;
	}

	public void setMi_mail(String mi_mail) {
		this.mi_mail = mi_mail;
	}

	public String getMi_birth() {
		return mi_birth;
	}

	public void setMi_birth(String mi_birth) {
		this.mi_birth = mi_birth;
	}

	public String getMi_join() {
		return mi_join;
	}

	public void setMi_join(String mi_join) {
		this.mi_join = mi_join;
	}

	public String getMi_last() {
		return mi_last;
	}

	public void setMi_last(String mi_last) {
		this.mi_last = mi_last;
	}

	public String getMi_status() {
		return mi_status;
	}

	public void setMi_status(String mi_status) {
		this.mi_status = mi_status;
	}
}
