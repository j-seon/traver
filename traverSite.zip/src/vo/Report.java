package vo;

public class Report {
	private String mi_id, gp_id, re_rop, re_why, re_ip, re_date;
	private int rl_idx;
	
	public String getMi_id() {
		return mi_id;
	}
	public void setMi_id(String mi_id) {
		this.mi_id = mi_id;
	}
	public String getGp_id() {
		return gp_id;
	}
	public void setGp_id(String gp_id) {
		this.gp_id = gp_id;
	}
	public String getRe_rop() {
		return re_rop;
	}
	public void setRe_rop(String re_rop) {
		this.re_rop = re_rop;
	}
	public String getRe_why() {
		return re_why;
	}
	public void setRe_why(String re_why) {
		this.re_why = re_why;
	}
	public String getRe_ip() {
		return re_ip;
	}
	public void setRe_ip(String re_ip) {
		this.re_ip = re_ip;
	}
	public String getRe_date() {
		return re_date;
	}
	public void setRe_date(String re_date) {
		this.re_date = re_date;
	}
	public int getRl_idx() {
		return rl_idx;
	}
	public void setRl_idx(int rl_idx) {
		this.rl_idx = rl_idx;
	}
}
