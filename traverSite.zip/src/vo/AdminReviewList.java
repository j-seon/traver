package vo;

public class AdminReviewList {
    private int rl_idx, pi_id;
    private String mi_id, rl_pname, rl_content, rl_img1, rl_img2, rl_img3, rl_img4, rl_ip, rl_date, rl_last;
    
    public int getRl_idx() {
        return rl_idx;
    }
    public void setRl_idx(int rl_idx) {
        this.rl_idx = rl_idx;
    }
    public int getPi_id() {
        return pi_id;
    }
    public void setPi_id(int pi_id) {
        this.pi_id = pi_id;
    }
    public String getMi_id() {
        return mi_id;
    }
    public void setMi_id(String mi_id) {
        this.mi_id = mi_id;
    }
    public String getRl_pname() {
        return rl_pname;
    }
    public void setRl_pname(String rl_pname) {
        this.rl_pname = rl_pname;
    }
    public String getRl_content() {
        return rl_content;
    }
    public void setRl_content(String rl_content) {
        this.rl_content = rl_content;
    }
    public String getRl_img1() {
        return rl_img1;
    }
    public void setRl_img1(String rl_img1) {
        this.rl_img1 = rl_img1;
    }
    public String getRl_img2() {
        return rl_img2;
    }
    public void setRl_img2(String rl_img2) {
        this.rl_img2 = rl_img2;
    }
    public String getRl_img3() {
        return rl_img3;
    }
    public void setRl_img3(String rl_img3) {
        this.rl_img3 = rl_img3;
    }
    public String getRl_img4() {
        return rl_img4;
    }
    public void setRl_img4(String rl_img4) {
        this.rl_img4 = rl_img4;
    }
    public String getRl_ip() {
        return rl_ip;
    }
    public void setRl_ip(String rl_ip) {
        this.rl_ip = rl_ip;
    }
    public String getRl_date() {
        return rl_date;
    }
    public void setRl_date(String rl_date) {
        this.rl_date = rl_date;
    }
    public String getRl_last() {
        return rl_last;
    }
    public void setRl_last(String rl_last) {
        this.rl_last = rl_last;
    }
}
