package vo;

public class GoodPost {
    private String gp_id, gi_id, mi_id, mi_nickname, gp_mbti, gp_title, gp_list, gp_content, gp_img, gp_date, gp_last, gp_ip;
    private int gp_gcnt;
   
    public String getGp_id() {
        return gp_id;
    }
    public void setGp_id(String gp_id) {
        this.gp_id = gp_id;
    }
    public String getGi_id() {
        return gi_id;
    }
    public void setGi_id(String gi_id) {
        this.gi_id = gi_id;
    }
    public String getMi_id() {
        return mi_id;
    }
    public void setMi_id(String mi_id) {
        this.mi_id = mi_id;
    }
    public String getMi_nickname() {
        return mi_nickname;
    }
    public void setMi_nickname(String mi_nickname) {
        this.mi_nickname = mi_nickname;
    }
    public String getGp_mbti() {
        return gp_mbti;
    }
    public void setGp_mbti(String gp_mbti) {
        this.gp_mbti = gp_mbti;
    }
    public String getGp_title() {
        return gp_title;
    }
    public void setGp_title(String gp_title) {
        this.gp_title = gp_title;
    }
    public String getGp_list() {
        return gp_list;
    }
    public void setGp_list(String gp_list) {
        this.gp_list = gp_list;
    }
    public String getGp_content() {
        return gp_content;
    }
    public void setGp_content(String gp_content) {
        this.gp_content = gp_content;
    }
    public String getGp_img() {
        return gp_img;
    }
    public void setGp_img(String gp_img) {
        this.gp_img = gp_img;
    }
    public String getGp_date() {
        return gp_date;
    }
    public void setGp_date(String gp_date) {
        this.gp_date = gp_date;
    }
    public String getGp_last() {
        return gp_last;
    }
    public void setGp_last(String gp_last) {
        this.gp_last = gp_last;
    }
    public String getGp_ip() {
        return gp_ip;
    }
    public void setGp_ip(String gp_ip) {
        this.gp_ip = gp_ip;
    }
    public int getGp_gcnt() {
        return gp_gcnt;
    }
    public void setGp_gcnt(int gp_gcnt) {
        this.gp_gcnt = gp_gcnt;
    }
}
