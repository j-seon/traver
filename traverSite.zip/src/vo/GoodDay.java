package vo;

public class GoodDay {
    private String gi_id, gd_name, gd_coords, gd_date;
    private int gd_id, pi_id, gd_dnum, gd_seq;
    
    public String getGi_id() {
        return gi_id;
    }
    public void setGi_id(String gi_id) {
        this.gi_id = gi_id;
    }
    public String getGd_name() {
        return gd_name;
    }
    public void setGd_name(String gd_name) {
        this.gd_name = gd_name;
    }
    public String getGd_coords() {
        return gd_coords;
    }
    public void setGd_coords(String gd_coords) {
        this.gd_coords = gd_coords;
    }
    public String getGd_date() {
        return gd_date;
    }
    public void setGd_date(String gd_date) {
        this.gd_date = gd_date;
    }
    public int getGd_id() {
        return gd_id;
    }
    public void setGd_id(int gd_id) {
        this.gd_id = gd_id;
    }
    public int getPi_id() {
        return pi_id;
    }
    public void setPi_id(int pi_id) {
        this.pi_id = pi_id;
    }
    public int getGd_dnum() {
        return gd_dnum;
    }
    public void setGd_dnum(int gd_dnum) {
        this.gd_dnum = gd_dnum;
    }
    public int getGd_seq() {
        return gd_seq;
    }
    public void setGd_seq(int gd_seq) {
        this.gd_seq = gd_seq;
    }
}
