package vo;

public class ScheduleZzim {
    private String gi_id,  mi_id;
    private int sz_idx;
    
    public String getGi_id() {
        return gi_id;
    }
    public void setGi_id(String gi_id) {
        this.gi_id = gi_id;
    }
    public String getMi_id() {
        return mi_id;
    }
    public void setMi_id(String mi_id) {
        this.mi_id = mi_id;
    }
    public int getSz_idx() {
        return sz_idx;
    }
    public void setSz_idx(int sz_idx) {
        this.sz_idx = sz_idx;
    }
}
