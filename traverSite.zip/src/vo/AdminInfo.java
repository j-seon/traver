package vo;

public class AdminInfo {
	private int ai_idx;
	private String ai_id, ai_pw, ai_name, ai_isuse, ai_date;
	
	public int getAi_idx() {
		return ai_idx;
	}
	public void setAi_idx(int ai_idx) {
		this.ai_idx = ai_idx;
	}
	public String getAi_id() {
		return ai_id;
	}
	public void setAi_id(String ai_id) {
		this.ai_id = ai_id;
	}
	public String getAi_pw() {
		return ai_pw;
	}
	public void setAi_pw(String ai_pw) {
		this.ai_pw = ai_pw;
	}
	public String getAi_name() {
		return ai_name;
	}
	public void setAi_name(String ai_name) {
		this.ai_name = ai_name;
	}
	public String getAi_isuse() {
		return ai_isuse;
	}
	public void setAi_isuse(String ai_isuse) {
		this.ai_isuse = ai_isuse;
	}
	public String getAi_date() {
		return ai_date;
	}
	public void setAi_date(String ai_date) {
		this.ai_date = ai_date;
	}
}
